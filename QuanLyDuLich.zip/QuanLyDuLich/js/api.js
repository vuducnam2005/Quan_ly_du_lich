const api = {
    getUsers: () => $.ajax({ url: API_USERS, method: 'GET' }),
    register: (data) => $.ajax({ url: API_USERS, method: 'POST', data }),

    getTours: () => $.ajax({ url: API_TOURS, method: 'GET' }),
    addTour: (data) => $.ajax({ url: API_TOURS, method: 'POST', data }),
    updateTour: (id, data) => $.ajax({ url: `${API_TOURS}/${id}`, method: 'PUT', data }),
    deleteTour: (id) => $.ajax({ url: `${API_TOURS}/${id}`, method: 'DELETE' })
};