const translations = {
    vi: {
        "nav_guest": "Khách",
        "nav_logout": "Đăng xuất",
        "hero_title": "Khám phá thế giới của bạn",
        "hero_desc": "Lên kế hoạch cho chuyến đi mơ ước ngay hôm nay với hàng ngàn ưu đãi.",
        "hero_btn": "Bắt đầu ngay",

        // Auth
        "auth_welcome": "Chào mừng trở lại!",
        "tab_login": "Đăng nhập",
        "tab_register": "Đăng ký",
        "lbl_email": "Email",
        "lbl_pass": "Mật khẩu",
        "lbl_name": "Họ tên",
        "btn_login": "Đăng nhập",
        "btn_register": "Đăng ký",
        
        // Dashboard
        "search_placeholder": "Tìm điểm đến...",
        "filter_loc_all": "📍 Tất cả địa điểm",
        "filter_price_def": "💲 Giá",
        "filter_price_asc": "Thấp đến cao",
        "filter_price_desc": "Cao đến thấp",
        "btn_add_tour": "Thêm Tour",
        "msg_no_tour": "Không tìm thấy tour nào.",
        
        // Card Tour
        "card_price": "Giá",
        "card_time": "Thời gian",
        
        // Modal Tour
        "modal_tour_title": "Thông tin Tour",
        "lbl_tour_name": "Tên Tour",
        "lbl_tour_dest": "Địa điểm",
        "lbl_tour_price": "Giá ($)",
        "lbl_tour_duration": "Thời lượng",
        "lbl_tour_desc": "Mô tả",
        "btn_save": "Lưu thông tin",
        
        // Modal Favorites
        "modal_fav_title": "Danh sách yêu thích",
        "btn_favorites": "Yêu thích",
        "msg_no_fav": "Chưa có tour yêu thích",

        // Alerts
        "alert_login_success": "Đăng nhập thành công!",
        "alert_login_fail": "Sai email hoặc mật khẩu",
        "alert_reg_success": "Đăng ký thành công! Hãy đăng nhập.",
        "alert_email_exist": "Email đã tồn tại!",
        "alert_added_fav": "Đã thêm vào yêu thích!",
        "alert_exist_fav": "Tour này đã có trong danh sách!",
        "confirm_delete": "Bạn có chắc chắn muốn xóa?"
    },
    en: {
        "nav_guest": "Guest",
        "nav_logout": "Logout",

        "hero_title": "Explore Your World",
        "hero_desc": "Plan your dream trip today with thousands of deals.",
        "hero_btn": "Get Started",

        // Auth
        "auth_welcome": "Welcome Back!",
        "tab_login": "Login",
        "tab_register": "Register",
        "lbl_email": "Email",
        "lbl_pass": "Password",
        "lbl_name": "Full Name",
        "btn_login": "Login",
        "btn_register": "Register",

        // Dashboard
        "search_placeholder": "Search destination...",
        "filter_loc_all": "📍 All Locations",
        "filter_price_def": "💲 Price",
        "filter_price_asc": "Low to High",
        "filter_price_desc": "High to Low",
        "btn_add_tour": "Add Tour",
        "msg_no_tour": "No tours found.",

        // Card Tour
        "card_price": "Price",
        "card_time": "Time",

        // Modal Tour
        "modal_tour_title": "Tour Information",
        "lbl_tour_name": "Tour Name",
        "lbl_tour_dest": "Destination",
        "lbl_tour_price": "Price ($)",
        "lbl_tour_duration": "Duration",
        "lbl_tour_desc": "Description",
        "btn_save": "Save Changes",

        // Modal Favorites
        "modal_fav_title": "Favorite List",
        "btn_favorites": "Favorites",
        "msg_no_fav": "No favorite tours yet",

        // Alerts
        "alert_login_success": "Login successfully!",
        "alert_login_fail": "Wrong email or password",
        "alert_reg_success": "Registration successful! Please login.",
        "alert_email_exist": "Email already exists!",
        "alert_added_fav": "Added to favorites!",
        "alert_exist_fav": "This tour is already in your list!",
        "confirm_delete": "Are you sure you want to delete?"
    }
};

const langManager = {
    currentLang: localStorage.getItem('lang') || 'vi',

    changeLanguage: function(lang) {
        this.currentLang = lang;
        localStorage.setItem('lang', lang);
        this.updateUI();
        if(typeof tours !== 'undefined') tours.loadTours(); 
        if(typeof auth !== 'undefined') auth.renderAuthUI();
        if(typeof favorites !== 'undefined') favorites.render();
    },
    getText: function(key) {
        return translations[this.currentLang][key] || key;
    },

    // Quét toàn bộ DOM và thay thế text
    updateUI: function() {
        $('[data-i18n]').each(function() {
            const key = $(this).data('i18n');
            const text = translations[langManager.currentLang][key];
            if ($(this).attr('placeholder')) {
                $(this).attr('placeholder', text);
            } else {
                $(this).text(text);
            }
        });
        $('.lang-btn').removeClass('active fw-bold');
        $(`.lang-btn[data-lang="${this.currentLang}"]`).addClass('active fw-bold');
    }
};