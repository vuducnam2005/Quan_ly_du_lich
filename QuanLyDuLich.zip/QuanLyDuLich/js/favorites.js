const favorites = {
    key: 'favTours',

    get: function() {
        return JSON.parse(localStorage.getItem(this.key)) || [];
    },

    add: function(tour) {
        let list = this.get();
        if (!list.find(i => i.id === tour.id)) {
            list.push({...tour, note: ''});
            localStorage.setItem(this.key, JSON.stringify(list));
            alert('Đã thêm vào yêu thích!');
            this.render();
        } else {
            alert('Tour này đã có trong danh sách!');
        }
    },

    remove: function(id) {
        let list = this.get().filter(i => i.id !== id);
        localStorage.setItem(this.key, JSON.stringify(list));
        this.render();
    },

    updateNote: function(id, note) {
        let list = this.get();
        let item = list.find(i => i.id === id);
        if(item) {
            item.note = note;
            localStorage.setItem(this.key, JSON.stringify(list));
        }
    },

    render: function() {
        const list = this.get();
        const html = list.map(t => `
            <li class="list-group-item d-flex justify-content-between align-items-center">
                <div>
                    <strong>${t.title}</strong> - ${t.price}$
                    <input type="text" class="form-control form-control-sm mt-1" 
                           placeholder="Ghi chú..." value="${t.note || ''}" 
                           onchange="favorites.updateNote('${t.id}', this.value)">
                </div>
                <button class="btn btn-danger btn-sm" onclick="favorites.remove('${t.id}')">Xóa</button>
            </li>
        `).join('');
        $('#favoritesList').html(html || '<p class="text-center">Chưa có tour yêu thích</p>');
    }
};