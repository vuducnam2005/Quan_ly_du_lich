// Thay thế bằng link MockAPI của bạn
const API_URL = "https://693994fec8d59937aa085fef.mockapi.io/api/v1"; 
const API_USERS = `${API_URL}/users`;
const API_TOURS = `${API_URL}/tours`;