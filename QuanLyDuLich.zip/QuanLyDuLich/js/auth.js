const auth = {
    // 1. Lấy thông tin user từ LocalStorage ngay khi khởi tạo
    user: JSON.parse(localStorage.getItem('currentUser')) || null,

    init: function() {
        // Gọi hàm hiển thị giao diện ngay khi tải trang
        this.renderAuthUI();

        // --- XỬ LÝ ĐĂNG KÝ ---
        $('#registerForm').on('submit', async function(e) {
            e.preventDefault();
            const email = $('#regEmail').val();
            
            try {
                // Kiểm tra email tồn tại
                const users = await api.getUsers();
                if (users.some(u => u.email === email)) {
                    alert(langManager.getText('alert_email_exist'));
                    return;
                }

                // Tạo user mới
                const newUser = {
                    name: $('#regName').val(),
                    email: email,
                    password: $('#regPass').val(),
                    createdAt: new Date().toISOString()
                };

                await api.register(newUser);
                alert(langManager.getText('alert_reg_success'));
                
                // QUAN TRỌNG: Chuyển về form Login sau khi đăng ký thành công
                // Bằng cách xóa class kích hoạt hiệu ứng trượt
                $('#slidingBox').removeClass("right-panel-active");
                
                // Reset form đăng ký để xóa dữ liệu cũ
                $('#registerForm')[0].reset();

            } catch (error) {
                console.error("Lỗi đăng ký:", error);
                alert("Có lỗi xảy ra, vui lòng thử lại.");
            }
        });

        // --- XỬ LÝ ĐĂNG NHẬP ---
        $('#loginForm').on('submit', async function(e) {
            e.preventDefault();
            const email = $('#loginEmail').val();
            const pass = $('#loginPass').val();
            
            try {
                const users = await api.getUsers();
                const user = users.find(u => u.email === email && u.password === pass);
                
                if (user) {
                    auth.login(user);
                } else {
                    alert(langManager.getText('alert_login_fail'));
                }
            } catch (error) {
                console.error("Lỗi đăng nhập:", error);
            }
        });
    },

    login: function(user) {
        this.user = user;
        localStorage.setItem('currentUser', JSON.stringify(user));
        this.renderAuthUI();
        // Load danh sách tour ngay sau khi đăng nhập
        if (typeof tours !== 'undefined') {
            tours.loadTours();
        }
    },

    logout: function() {
        this.user = null;
        localStorage.removeItem('currentUser');
        this.renderAuthUI();
        // Xóa danh sách tour khỏi giao diện
        $('#tourList').empty();
    },

    // --- HÀM ĐIỀU KHIỂN GIAO DIỆN (QUAN TRỌNG) ---
    renderAuthUI: function() {
        const authSection = $('#authSection');
        
        // TRƯỜNG HỢP 1: ĐÃ ĐĂNG NHẬP
        if (this.user) {
            // 1. Navbar hiện tên user và nút Logout
            authSection.html(`
                <div class="dropdown">
                    <button class="btn btn-light rounded-pill dropdown-toggle shadow-sm border" type="button" data-bs-toggle="dropdown">
                        <i class="fas fa-user-circle text-primary"></i> ${this.user.name}
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end shadow border-0">
                        <li><a class="dropdown-item text-danger" href="#" onclick="auth.logout()">
                            <i class="fas fa-sign-out-alt"></i> ${langManager.getText('nav_logout')}
                        </a></li>
                    </ul>
                </div>
            `);
            
     
            $('#authContainer').addClass('d-none');
            
       
            $('#dashboard').removeClass('d-none')

            $('#heroBanner').removeClass('d-none')
            $('body').css({'height': 'auto', 'overflow': 'auto', 'justify-content': 'flex-start'});
            
        } else {
            
            authSection.html(`
                <button class="btn btn-primary rounded-pill px-4 shadow-sm" 
                        onclick="document.getElementById('authContainer').scrollIntoView({behavior: 'smooth'})">
                    ${langManager.getText('tab_login')}
                </button>
            `);
            
            // 2. Hiện khung đăng nhập
            $('#authContainer').removeClass('d-none');
            
            // 3. Ẩn Dashboard
            $('#dashboard').addClass('d-none');
            $('#heroBanner').addClass('d-none');
            $('body').css({
                'min-height': '100vh',
                'display': 'flex',
                'flex-direction': 'column',
                'justify-content': 'center'
            });
            // 4. Mặc định reset về form Đăng nhập (tránh bị kẹt ở form Đăng ký)
            // Xóa class 'right-panel-active' để Sliding Box trượt về bên trái (Login)
            $('#slidingBox').removeClass("right-panel-active");

            
        }
    }
};