
const convertBase64 = (file) => {
    return new Promise((resolve, reject) => {
        const fileReader = new FileReader();
        fileReader.readAsDataURL(file);

        fileReader.onload = () => {
            resolve(fileReader.result);
        };

        fileReader.onerror = (error) => {
            reject(error);
        };
    });
};

window.previewImage = function (input) {
    const file = input.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = function (e) {
            $('#imgPreview').attr('src', e.target.result).show();
            $('#imgPlaceholder').hide();
        }
        reader.readAsDataURL(file);
    }
}

const tours = {
    list: [],

    loadTours: async function () {
        try {
            this.list = await api.getTours();
            this.render(this.list);
            this.updateLocationFilter();
        } catch (error) {
            console.error(error);
        }
    },

    render: function (data) {
        if (data.length === 0) {
            $('#tourList').html('<div class="col-12 text-center text-muted py-5">Chưa có tour nào</div>');
            return;
        }

        const html = data.map(t => {

            const imgSrc = t.image && t.image.length > 10 ? t.image : 'https://via.placeholder.com/400x250?text=No+Image';

            return `
            <div class="col-md-4 col-sm-6 mb-4">
                <div class="card tour-card h-100 shadow-sm border-0 rounded-4 overflow-hidden">
                    
                    <div class="tour-img-wrapper position-relative" style="height: 220px;">
                        <img src="${imgSrc}" alt="${t.title}" style="width: 100%; height: 100%; object-fit: cover;">
                        <span class="badge bg-dark bg-opacity-75 position-absolute top-0 end-0 m-3 px-3 py-2 rounded-pill">
                            <i class="far fa-clock"></i> ${t.duration}
                        </span>
                    </div>

                    <div class="card-body d-flex flex-column p-4"> <h5 class="card-title fw-bold text-truncate mb-1" title="${t.title}">${t.title}</h5>
                        <div class="mb-3 text-muted small">
                            <i class="fas fa-map-marker-alt text-danger me-1"></i> ${t.destination}
                        </div>
                        
                        <p class="card-text text-secondary small text-truncate mb-4" style="-webkit-line-clamp: 2; display: -webkit-box; -webkit-box-orient: vertical; white-space: normal;">
                            ${t.description}
                        </p>
                        
                        <div class="mt-auto d-flex justify-content-between align-items-center">
                            <span class="fw-bold text-primary fs-5">$${t.price}</span>
                            
                            <div class="d-flex gap-2"> <button class="btn btn-light text-primary btn-sm rounded-circle shadow-sm btn-action" 
                                        onclick="tours.edit('${t.id}')" title="Sửa" style="width: 38px; height: 38px;">
                                    <i class="fas fa-pen"></i>
                                </button>
                                
                                <button class="btn btn-light text-danger btn-sm rounded-circle shadow-sm btn-action" 
                                        onclick="tours.del('${t.id}')" title="Xóa" style="width: 38px; height: 38px;">
                                    <i class="fas fa-trash"></i>
                                </button>

                                <button class="btn btn-light text-danger btn-sm rounded-circle shadow-sm btn-action" 
                                        onclick='favorites.add(${JSON.stringify(t)})' title="Yêu thích" style="width: 38px; height: 38px;">
                                    <i class="fas fa-heart"></i>
                                </button>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            `;
        }).join('');
        $('#tourList').html(html);
    },
    handleFormSubmit: async function (e) {
        e.preventDefault();

        const id = $('#tourId').val();
        const fileInput = document.getElementById('tourImgFile');
        const file = fileInput.files[0];

        let imageBase64 = $('#tourImgBase64').val(); 

 
        if (file) {
            try {
                imageBase64 = await convertBase64(file);
            } catch (error) {
                alert("Lỗi khi đọc file ảnh!");
                return;
            }
        }

        const data = {
            title: $('#tourTitle').val(),
            destination: $('#tourDest').val(),
            price: Number($('#tourPrice').val()),
            duration: $('#tourDuration').val(),
            description: $('#tourDesc').val(),
            image: imageBase64, // Lưu chuỗi Base64 vào cột image
            createdAt: new Date().toISOString()
        };

        try {
            if (id) {
                await api.updateTour(id, data);
            } else {
                await api.addTour(data);
            }
            $('#tourModal').modal('hide');
            this.loadTours(); 
        } catch (err) {
            alert("Lỗi: Ảnh có thể quá lớn so với giới hạn của MockAPI!");
            console.error(err);
        }
    },

    edit: function (id) {
        const t = this.list.find(i => i.id === id);

        $('#tourId').val(t.id);
        $('#tourTitle').val(t.title);
        $('#tourDest').val(t.destination);
        $('#tourPrice').val(t.price);
        $('#tourDuration').val(t.duration);
        $('#tourDesc').val(t.description);

        // Xử lý hiển thị ảnh cũ
        $('#tourImgFile').val(''); // Reset ô chọn file
        $('#tourImgBase64').val(t.image || ''); // Lưu link ảnh cũ vào input ẩn

        if (t.image && t.image.length > 10) {
            $('#imgPreview').attr('src', t.image).show();
            $('#imgPlaceholder').hide();
        } else {
            $('#imgPreview').hide();
            $('#imgPlaceholder').show();
        }

        $('#tourModal').modal('show');
    },

    del: async function (id) {
        if (confirm('Bạn có chắc chắn muốn xóa?')) {
            await api.deleteTour(id);
            this.loadTours();
        }
    },

    filterAndSearch: function () {
        let result = [...this.list];
        const searchVal = $('#searchInput').val().toLowerCase();
        const locVal = $('#filterLocation').val();
        const priceSort = $('#filterPrice').val();

        if (searchVal) {
            result = result.filter(t =>
                t.title.toLowerCase().includes(searchVal) ||
                t.duration.toLowerCase().includes(searchVal)
            );
        }

        if (locVal) {
            result = result.filter(t => t.destination === locVal);
        }


        if (priceSort === 'asc') result.sort((a, b) => a.price - b.price);
        if (priceSort === 'desc') result.sort((a, b) => b.price - a.price);

        this.render(result);
    },

    updateLocationFilter: function () {
        const locations = [...new Set(this.list.map(t => t.destination))];
        const html = '<option value="desc" data-i18n="filter_loc_all">Tất cả địa điểm</option>' +
            locations.map(l => `<option value="${l}">${l}</option>`).join('');
        $('#filterLocation').html(html);
    }
};

window.resetTourForm = function () {
    $('#tourForm')[0].reset();
    $('#tourId').val('');
    $('#tourImgBase64').val('');
    $('#imgPreview').attr('src', '').hide();
    $('#imgPlaceholder').show();
}